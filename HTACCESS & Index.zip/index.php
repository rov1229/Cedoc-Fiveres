<?php
// Error reporting configuration (enable for debugging)
error_reporting(E_ALL);
ini_set('display_errors', 1); // Set to 0 in production

// Define application paths (exactly matching your structure)
define('BASE_PATH', __DIR__);
define('ADMIN_PATH', BASE_PATH . '/AdminAccount/Admin');
define('ADMIN_BACKEND_PATH', BASE_PATH . '/AdminAccount/AdminBackEnd');
define('SUPER_ADMIN_PATH', BASE_PATH . '/SuperAdminAccount/SuperAdmin');
define('SUPER_ADMIN_BACKEND_PATH', BASE_PATH . '/SuperAdminAccount/AdminBackEnd');
define('USER_PATH', BASE_PATH . '/UserAccount/user');
define('USER_BACKEND_PATH', BASE_PATH . '/UserAccount/userBackEnd');
define('INTERN_PATH', BASE_PATH . '/Intern');
define('LOGIN_PATH', BASE_PATH . '/login');
define('ASSETS_PATH', BASE_PATH . '/Assets');

// Secure session configuration
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'name' => 'SecureSessionID',
        'cookie_lifetime' => 14400,
        'cookie_secure' => isset($_SERVER['HTTPS']),
        'cookie_httponly' => true,
        'cookie_samesite' => 'Strict',
        'use_strict_mode' => true,
        'use_only_cookies' => 1,
        'gc_maxlifetime' => 14400
    ]);
}

// Security headers
header("X-Frame-Options: DENY");
header("X-Content-Type-Options: nosniff");
header("X-XSS-Protection: 1; mode=block");
header("Referrer-Policy: strict-origin-when-cross-origin");

// Authentication check functions
function is_authenticated() {
    return isset($_SESSION['user_id']);
}

function is_admin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'Admin';
}

function is_super_admin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'SuperAdmin';
}

function is_user() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'User';
}

function is_intern() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'Intern';
}

// Main routing function
function route_request() {
    $request_uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $request_path = trim($request_uri, '/');
    
    // Skip static assets
    if (preg_match('/\.(css|js|jpg|jpeg|png|gif|ico|pdf|woff|woff2|ttf|svg)$/i', $request_uri)) {
        return false;
    }
    
    // Admin routes
    if (strpos($request_path, 'AdminAccount/') === 0) {
        if (!is_authenticated() || !is_admin()) {
            header('Location: /login/login.php');
            exit();
        }
        $admin_route = substr($request_path, 13);
        handle_admin_request($admin_route);
        return true;
    }
    
    // Super Admin routes
    if (strpos($request_path, 'SuperAdminAccount/') === 0) {
        if (!is_authenticated() || !is_super_admin()) {
            header('Location: /login/login.php');
            exit();
        }
        $super_admin_route = substr($request_path, 18);
        handle_super_admin_request($super_admin_route);
        return true;
    }
    
    // User routes
    if (strpos($request_path, 'UserAccount/') === 0) {
        if (!is_authenticated() || !is_user()) {
            header('Location: /login/login.php');
            exit();
        }
        $user_route = substr($request_path, 12);
        handle_user_request($user_route);
        return true;
    }
    
    // Intern routes
    if (strpos($request_path, 'Intern/') === 0) {
        if (!is_authenticated() || !is_intern()) {
            header('Location: /login/login.php');
            exit();
        }
        $intern_route = substr($request_path, 7);
        handle_intern_request($intern_route);
        return true;
    }
    
    // Login routes
    if ($request_path === 'login' || strpos($request_path, 'login/') === 0) {
        $login_route = substr($request_path, 6);
        handle_login_request($login_route);
        return true;
    }
    
    // Root request
    if (empty($request_path) || $request_path === 'index.php') {
        if (is_authenticated()) {
            redirect_authenticated_user();
        } else {
            header('Location: /login/login.php');
            exit();
        }
    }
    
    // 404 Not Found
    http_response_code(404);
    show_404();
    exit();
}

function redirect_authenticated_user() {
    if (is_super_admin()) {
        header('Location: /SuperAdminAccount/SuperAdmin/SuperAdminDashboard.php');
    } elseif (is_admin()) {
        header('Location: /AdminAccount/Admin/adminDashboard.php');
    } elseif (is_user()) {
        header('Location: /UserAccount/user/userDashboard.php');
    } elseif (is_intern()) {
        header('Location: /Intern/internHome.php');
    }
    exit();
}

function show_404() {
    if (file_exists(__DIR__ . '/login/not-found.php')) {
        include __DIR__ . '/login/not-found.php';
    } else {
        die('<h1>404 Not Found</h1><p>The requested page was not found.</p>');
    }
}

// Route handlers with exact paths from your structure
function handle_admin_request($route) {
    $admin_routes = [
        '' => 'adminDashboard.php',
        'Admin' => 'adminDashboard.php',
        'adminDashboard' => 'adminDashboard.php',
        'manage-users' => 'manage-users.php',
        'media-files' => 'media-files.php',
        'Profile' => 'Profile.php',
        'resume' => 'resume.php',
        'vehicle-runs' => 'vehicle-runs.php',
        'view-folder' => 'view-folder.php'
    ];
    
    if (isset($admin_routes[$route])) {
        $file = ADMIN_PATH . '/' . $admin_routes[$route];
        if (file_exists($file)) {
            require $file;
            return;
        }
    }
    show_404();
    exit();
}

function handle_super_admin_request($route) {
    $super_admin_routes = [
        '' => 'SuperAdminDashboard.php',
        'SuperAdmin' => 'SuperAdminDashboard.php',
        'SuperAdminDashboard' => 'SuperAdminDashboard.php',
        'manage-users' => 'manage-users.php',
        'media-files' => 'media-files.php',
        'Profile' => 'Profile.php',
        'resume' => 'resume.php',
        'vehicle-runs' => 'vehicle-runs.php',
        'view-folder' => 'view-folder.php'
    ];
    
    if (isset($super_admin_routes[$route])) {
        $file = SUPER_ADMIN_PATH . '/' . $super_admin_routes[$route];
        if (file_exists($file)) {
            require $file;
            return;
        }
    }
    show_404();
    exit();
}

function handle_user_request($route) {
    $user_routes = [
        '' => 'userDashboard.php',
        'user' => 'userDashboard.php',
        'userDashboard' => 'userDashboard.php',
        'media-files' => 'media-files.php',
        'Profile' => 'Profile.php',
        'resume' => 'resume.php',
        'vehicle-runs' => 'vehicle-runs.php',
        'view-folder' => 'view-folder.php'
    ];
    
    if (isset($user_routes[$route])) {
        $file = USER_PATH . '/' . $user_routes[$route];
        if (file_exists($file)) {
            require $file;
            return;
        }
    }
    show_404();
    exit();
}

function handle_intern_request($route) {
    $intern_routes = [
        '' => 'internHome.php',
        'internHome' => 'internHome.php',
        'internAbout' => 'internAbout.php',
        'internApplication' => 'internApplication.php'
    ];
    
    if (isset($intern_routes[$route])) {
        $file = INTERN_PATH . '/' . $intern_routes[$route];
        if (file_exists($file)) {
            require $file;
            return;
        }
    }
    show_404();
    exit();
}

function handle_login_request($route) {
    $login_routes = [
        '' => 'login.php',
        'login' => 'login.php',
        'forgotpassword' => 'forgotpassword.php',
        'resetpassword' => 'resetpassword.php',
        'logout' => 'logout.php'
    ];
    
    if (isset($login_routes[$route])) {
        $file = LOGIN_PATH . '/' . $login_routes[$route];
        if (file_exists($file)) {
            require $file;
            return;
        }
    }
    show_404();
    exit();
}

// Execute routing
route_request();